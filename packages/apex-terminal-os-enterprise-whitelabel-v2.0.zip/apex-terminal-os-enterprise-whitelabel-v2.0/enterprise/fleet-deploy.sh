#!/usr/bin/env bash
# 🏛️ APEX TERMINAL OS — ENTERPRISE MULTI-MAC SSH FLEET PROVISIONER
# Deploys Apex Terminal OS + Custom Agency White-Label Branding across engineering workstations.
set -e
BRAND="${1:-ENTERPRISE ENGINEERING OS}"
TAGLINE="${2:-AUTONOMOUS COMMAND CENTER}"
echo "==> Deploying Enterprise Fleet Branding: $BRAND ($TAGLINE)"
"$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/install/setup.sh"
"$HOME/.local/bin/apex-whitelabel" --brand "$BRAND" --tagline "$TAGLINE"
echo "✓ Enterprise workstation provisioned."
